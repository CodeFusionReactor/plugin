package com.edwardjones.vpr.tbsapi.configuration;

import org.springframework.context.annotation.Configuration;

@Configuration
public class ApplicationConfiguration {
}
