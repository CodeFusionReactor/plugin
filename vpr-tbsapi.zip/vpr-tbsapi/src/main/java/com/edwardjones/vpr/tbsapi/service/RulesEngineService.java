package com.edwardjones.vpr.tbsapi.service;

import com.edwardjones.vpr.tbsapi.client.rulesengine.RulesEngineClient;
import org.springframework.stereotype.Component;

/**
 * Service class which provides access to TBS rules engine API.
 */
interface RulesEngineService {
}
