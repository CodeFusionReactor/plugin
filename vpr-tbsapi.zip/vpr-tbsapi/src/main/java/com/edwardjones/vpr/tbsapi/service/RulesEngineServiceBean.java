package com.edwardjones.vpr.tbsapi.service;

import org.springframework.stereotype.Service;

@Service
public class RulesEngineServiceBean {
}
