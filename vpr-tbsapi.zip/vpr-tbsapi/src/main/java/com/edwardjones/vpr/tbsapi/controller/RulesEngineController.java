package com.edwardjones.vpr.tbsapi.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * This class provides a REST facade to the TBS rules engine.
 */
@RestController
@RequestMapping("/rules-engine")
public class RulesEngineController {
}
