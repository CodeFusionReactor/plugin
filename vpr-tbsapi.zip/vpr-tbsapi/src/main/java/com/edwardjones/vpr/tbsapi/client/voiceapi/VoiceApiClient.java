package com.edwardjones.vpr.tbsapi.client.voiceapi;

import org.springframework.stereotype.Component;

@Component
public class VoiceApiClient {

}
