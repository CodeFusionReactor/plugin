package com.edwardjones.vpr.tbsapi.service;

import com.edwardjones.vpr.tbsapi.exception.SupplementalRingException;
import com.edwardjones.vpr.tbsapi.model.PhoneController;
import com.edwardjones.vpr.tbsapi.model.PhoneNumber;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * {@link VoiceService} class implementation.
 */
@Service
public class VoiceServiceBean implements VoiceService {
    /**
     * {@inheritDoc}
     */
    @Override
    public void disableSupplementalRing(String branchNumber) {

        // Supplemental ring only works with Toshiba.
        if (PhoneController.TOSHIBA != findPhoneController(branchNumber)) {
            throw new SupplementalRingException();
        }

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void enableSupplementalRing(String branchNumber, List<PhoneNumber> phoneNumbers) {

        // Supplemental ring only works with Toshiba.
        if (PhoneController.TOSHIBA != findPhoneController(branchNumber)) {
            throw new SupplementalRingException();
        }

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public PhoneController findPhoneController(String branchNumber) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Optional<PhoneNumber> findSupplementalRingPhoneNumber(String branchNumber) {
        return Optional.empty();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isSupplementalRingEnabled(String branchNumber) {
        return false;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public List<PhoneNumber> supplementalRingPhoneNumbers(String branchNumber) {
        return null;
    }
}
