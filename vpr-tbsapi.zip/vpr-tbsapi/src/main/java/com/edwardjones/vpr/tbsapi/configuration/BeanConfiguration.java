package com.edwardjones.vpr.tbsapi.configuration;

import org.springframework.stereotype.Component;

@Component
public class BeanConfiguration {

}
