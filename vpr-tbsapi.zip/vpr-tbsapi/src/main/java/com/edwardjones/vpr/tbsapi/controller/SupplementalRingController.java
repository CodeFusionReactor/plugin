package com.edwardjones.vpr.tbsapi.controller;

import com.edwardjones.vpr.tbsapi.model.PhoneNumber;
import com.edwardjones.vpr.tbsapi.service.VoiceServiceBean;
import lombok.Builder;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/feature/supplemental-ring/{branchNumber}")
public class SupplementalRingController {

    private final VoiceServiceBean voiceService;

    @Autowired
    public SupplementalRingController(VoiceServiceBean voiceService) {this.voiceService = voiceService;}

    /**
     * This endpoint will return the current status of supplemental ring for the
     * specified branch office.
     *
     * @param branchNumber branch number
     *
     * @return {@link SupplementalRingResponse} object
     */
    @GetMapping
    public ResponseEntity<SupplementalRingResponse> getSupplementalRingStatus(
            @PathVariable("branchNumber") String branchNumber) {

        return ResponseEntity.ok(SupplementalRingResponse.builder().build());
    }

    /**
     * This endpoint is used to enable or disable supplemental ring for the
     * specified branch office.
     *
     * @param branchNumber branch number
     * @param request      {@link SupplementalRingRequest} object
     *
     * @return {@link SupplementalRingResponse} object
     */
    @PostMapping
    public ResponseEntity<SupplementalRingResponse> postSupplementalRing(
            @PathVariable("branchNumber") String branchNumber,
            @RequestBody SupplementalRingRequest request) {

        if (request.isEnabled()) {
            voiceService.enableSupplementalRing(branchNumber, request.getAdditionalRingPhones());
        }
        else {
            voiceService.disableSupplementalRing(branchNumber);
        }

        SupplementalRingResponse response =
                SupplementalRingResponse.builder()
                                        .branchNumber(branchNumber)
                                        .additionalRingPhones(request.getAdditionalRingPhones())
                                        .build();

        return ResponseEntity.ok(response);
    }
}

/**
 * DTO class used when making a request to enable or disable supplemental ring.
 */
@Data
@Builder
class SupplementalRingRequest {
    private List<PhoneNumber> additionalRingPhones;
    private boolean enabled;
}

/**
 * DTO class used to return the status of supplemental ring.
 */
@Data
@Builder
class SupplementalRingResponse {
    private List<PhoneNumber> additionalRingPhones;
    private String branchNumber;
    private boolean enabled;
    private PhoneNumber ringPhone;
}
