package com.edwardjones.vpr.tbsapi.model;

import lombok.Data;

import java.io.Serializable;

@Data
public class PhoneNumber implements Serializable {

    private String e164Number;
    private String nationalNumber;
}
