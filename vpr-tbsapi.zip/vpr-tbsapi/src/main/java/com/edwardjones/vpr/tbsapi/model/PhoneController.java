package com.edwardjones.vpr.tbsapi.model;

public enum PhoneController {
    TOSHIBA,VONAGE,RING_CENTRAL,UNKNOWN
}
