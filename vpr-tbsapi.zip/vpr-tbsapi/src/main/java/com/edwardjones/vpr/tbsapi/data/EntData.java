package com.edwardjones.vpr.tbsapi.data;

/**
 * MyBatis interface.
 */
public class EntData {
}
