package com.edwardjones.vpr.tbsapi.service;

import com.edwardjones.vpr.tbsapi.model.PhoneController;
import com.edwardjones.vpr.tbsapi.model.PhoneNumber;

import java.util.List;
import java.util.Optional;

interface VoiceService {

    /**
     * Disables supplemental ring at the specified branch office.
     *
     * @param branchNumber branch number
     */
    void disableSupplementalRing(String branchNumber);

    /**
     * Enables supplemental ring at the specified branch office if the branch
     * has an assigned third-line, or a list of alternate/additional phone numbers
     * is provided.
     *
     * @param branchNumber branch number
     * @param phoneNumbers list of phone number(s) to simultaneously ring.
     */
    void enableSupplementalRing(String branchNumber, List<PhoneNumber> phoneNumbers);

    /**
     * Returns the type of phone controller used at the specified branch office.
     *
     * @param branchNumber branch number
     *
     * @return {@link PhoneController}
     */
    PhoneController findPhoneController(String branchNumber);

    /**
     * If the specified branch office has an additional phone line installed for
     * supplemental ring then the phone number is returned.
     *
     * @param branchNumber branch number
     *
     * @return Optional phone number
     */
    Optional<PhoneNumber> findSupplementalRingPhoneNumber(String branchNumber);

    /**
     * Returns {@code true} if the specified branch office is using supplemental
     * ring.
     *
     * @param branchNumber branch number
     *
     * @return boolean
     */
    boolean isSupplementalRingEnabled(String branchNumber);

    List<PhoneNumber> supplementalRingPhoneNumbers(String branchNumber);
}
