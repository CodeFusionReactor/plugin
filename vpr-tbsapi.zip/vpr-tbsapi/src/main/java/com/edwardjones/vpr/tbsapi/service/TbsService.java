package com.edwardjones.vpr.tbsapi.service;

public interface TbsService {

}
