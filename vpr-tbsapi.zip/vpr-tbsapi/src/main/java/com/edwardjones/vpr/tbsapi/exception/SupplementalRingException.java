package com.edwardjones.vpr.tbsapi.exception;

public class SupplementalRingException extends ApplicationException {
}
