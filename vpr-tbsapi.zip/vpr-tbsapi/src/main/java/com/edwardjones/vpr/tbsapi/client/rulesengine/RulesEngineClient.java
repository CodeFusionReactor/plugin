package com.edwardjones.vpr.tbsapi.client.rulesengine;

import org.springframework.stereotype.Component;

/**
 * This class provides access to the TBS rules engine SOAP and REST services.
 */
@Component
public class RulesEngineClient {
}
