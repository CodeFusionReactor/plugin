package com.edwardjones.vpr.tbsapi.exception;

public class ApplicationException extends RuntimeException {
}
