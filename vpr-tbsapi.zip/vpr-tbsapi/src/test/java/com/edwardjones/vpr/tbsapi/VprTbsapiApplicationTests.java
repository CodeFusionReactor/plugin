package com.edwardjones.vpr.tbsapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VprTbsapiApplicationTests {

    @Test
    void contextLoads() {
    }

}
